# Image Search ML project
The project contains an implementation of a semantic search engine. 
The implementation is based on leveraging pre-trained embeddings from VGG16 (trained on Imagenet), and GloVe (trained on Wikipedia).

It allows you to:
- Similar images to an input image
- Similar words to an input word
- Search through images using any word
- Generate tags for any image


## Setup
Run the codes with Python 3.6

In command prompt
```
cd C:\Users\harini\Desktop\ML internship
pip install tensorflow
pip install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-0.12.0-py3-none-any-whl
pip install keras
pip install annoy
pip install sklearn
pip install pillow
 

Codes
--Feature Extraction
--Image Processing
--Vector search
--Training Id
--Search the Images



### Running the pipeline end to end
```
python demo.py \
  --features path 
  --file mapping path
  --loading the datasets
  --indexing the images
  --search key 
  --training Id
  --search images

```

