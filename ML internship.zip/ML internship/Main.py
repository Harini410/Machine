import logging
import os
import json
import time
import inspect
import PIL
from PIL import Image
from vector_search import vector_search
from annoy import AnnoyIndex
from keras.preprocessing import image
from keras.callbacks import ModelCheckpoint
from keras.models import load_model
from keras import optimizers
from keras.models import Model
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from argparse import ArgumentParser



# Caching some functions
train_test_split = st.cache(train_test_split)
vector_search.load_glove_vectors = st.cache(vector_search.load_glove_vectors)

# Feature path
@st.cache
def to_array(image_path):
    img = image.load_img(image_path, target_size=(224, 224))
    x_raw = image.img_to_array(img)
    return x_raw.astype(np.uint8)

def show_top_n(n, res, search_by_img=True):
    top_n = np.stack([to_array(res[i][1]) for i in range(min(len(res), n))])
    captions = [res[i][2] for i in range(min(len(res), n))]
    if search_by_img:
        captions[0] = "Original"
    st.image(top_n, caption=captions)

def show_source(fn):
    st.write('```\n%s\n```' % inspect.getsource(fn))

# File mapping path
def build_parser():
    par = ArgumentParser()
    par.add_argument('--features_path', type=str,
                     dest='features_path', help='filepath to save/load features in simple model',
                     default="feat_4096")
    par.add_argument('--file_mapping_path', type=str,
                     dest='file_mapping_path', help='filepath to index file for simple model',
                     default="index_4096")
    par.add_argument('--model_path', type=str,
                     dest='model_path', help='Model path',
                     default="my_model.hdf5")
    par.add_argument('--custom_features_path', type=str,
                     dest='custom_features_path', help='filepath to save/load features in complex model',
                     default="feat_300")
    par.add_argument('--custom_features_file_mapping_path', type=str,
                     dest='custom_features_file_mapping_path', help='filepath to index in complex model',
                     default="index_300")
    par.add_argument('--search_key', type=int,
                     dest='search_key', help='Select a search key, 200 suggested',
                     default=200)
    par.add_argument('--train_model', type=str,
                     dest='train_model', help='Boolean True/False to train',
                     default="False")
    par.add_argument('--generate_image_features', type=str,
                     dest='generate_image_features', help='Boolean True/False to generate image features',
                     default="False")
    par.add_argument('--generate_custom_features', type=str,
                     dest='generate_custom_features', help='Boolean True/False to generate custom features',
                     default="False")
    par.add_argument('--training_epochs', type=int,
                     dest='training_epochs', help='Total training epochs for the complex model',
                     default=2)
    par.add_argument('--batch_size_training', type=int,
                     dest='batch_size_training', help='Total training epochs for the complex model',
                     default=32)
    par.add_argument('--glove_model_path', type=str,
                     dest='glove_model_path', help='Relative destination to glove model path',
                     default="models/glove.6B")
    par.add_argument('--data_path', type=str,
                     dest='data_path', help='Relative destination to dataset folder path',
                     default="dataset")
    return par

def str2bool(v):
  return v.lower() in ("yes", "true", "t", "1")

def load_images_vectors_paths(glove_model_path, data_path):
    word_vectors = vector_search.load_glove_vectors(glove_model_path)
    images, vectors, image_paths = load_paired_img_wrd(data_path, word_vectors)
    return images, vectors, image_paths, word_vectors


if __name__ == '__main__':
    parser = build_parser()
    options = parser.parse_args()
    features_path = options.features_path
    file_mapping_path = options.file_mapping_path
    model_path = options.model_path
    custom_features_path = options.custom_features_path
    custom_features_file_mapping_path = options.custom_features_file_mapping_path
    search_key = options.search_key
    train_model = str2bool(options.train_model)
    generate_image_features = str2bool(options.generate_image_features)
    generate_custom_features = str2bool(options.generate_custom_features)
    training_epochs = options.training_epochs
    batch_size_training = options.batch_size_training
    glove_model_path = options.glove_model_path
    data_path = options.data_path




# Loading the datasets 

def load_paired_img_wrd(folder, word_vectors, use_word_vectors=True):
    '''
    If use_word_vectors = true, and using VGG16 with Imagenet:
    Will have 300 embedding layer at end of network
    Instead of 4096 imagenet class layer at the end of the network
    '''
    class_names = [fold for fold in os.listdir(folder) if ".DS" not in fold]
    image_list = []
    labels_list = []
    paths_list = []
    for cl in class_names:
        splits = cl.split("_")
        if use_word_vectors:
            vectors = np.array([word_vectors[split] if split in word_vectors else np.zeros(shape=300) for split in splits])
            class_vector = np.mean(vectors, axis=0)
        subfiles = [f for f in os.listdir(folder + "/" + cl) if ".DS" not in f]

        for subf in subfiles:
            full_path = os.path.join(folder, cl, subf)
            img = image.load_img(full_path, target_size=(224, 224))
            x_raw = image.img_to_array(img)
            x_expand = np.expand_dims(x_raw, axis=0)
            x = preprocess_input(x_expand)
            image_list.append(x)
            if use_word_vectors:
                labels_list.append(class_vector)
            paths_list.append(full_path)
    img_data = np.array(image_list)
    img_data = np.rollaxis(img_data, 1, 0)
    img_data = img_data[0]

    return img_data, np.array(labels_list), paths_list


def check_inputs(folder, image, word, model_path, glove_path):
    if not folder and not (image or word):
        raise ValueError(
            "You must either provide a folder to index, or an image/word to search, you provided %s folder, %s image, "
            "%s word " % (folder, image, word))
    if folder is not None and (image or word) is not None:
        raise ValueError("You must provide either a folder to index, or an image/word to search, not both or neither. "
                         "You provided %s folder, %s image, %s word" % (folder, image, word))

    if (word is True) != (model_path is True):
        raise ValueError("Ypu must provide a custom model if searching by word, you provided %s for word and %s for "
                         "model" % (word, model_path))
    if (model_path is True) != (glove_path is True):
        raise ValueError("Ypu must provide a glove path if training custom model, you provided %s for model and %s for "
                         "glove" % (model_path, glove_path))

# Indexing the images

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def load_headless_pretrained_model():
    """
    Loads the pretrained version of VGG with the last layer cut off
    :return: pre-trained headless VGG16 Keras Model
    """
    print ("Loading headless pretrained model...")
    pretrained_vgg16 = VGG16(weights='imagenet', include_top=True)
    model = Model(inputs=pretrained_vgg16.input,
                  outputs=pretrained_vgg16.get_layer('fc2').output)
    return model


def generate_features(image_paths, model):
    """
    Takes in an array of image paths, and a trained model.
    Returns the activations of the last layer for each image
    :param image_paths: array of image paths
    :param model: pre-trained model
    :return: array of last-layer activations, and mapping from array_index to file_path
    """
    print ("Generating features...")
    start = time.time()
    images = np.zeros(shape=(len(image_paths), 224, 224, 3))
    file_mapping = {i: f for i, f in enumerate(image_paths)}

    # We load all our dataset in memory because it is relatively small
    for i, f in enumerate(image_paths):
        img = image.load_img(f, target_size=(224, 224))
        x_raw = image.img_to_array(img)
        x_expand = np.expand_dims(x_raw, axis=0)
        images[i, :, :, :] = x_expand

    logger.info("%s images loaded" % len(images))
    inputs = preprocess_input(images)
    logger.info("Images preprocessed")
    images_features = model.predict(inputs)
    end = time.time()
    logger.info("Inference done, %s Generation time" % (end - start))
    return images_features, file_mapping


def save_features(features_filename, features, mapping_filename, file_mapping):
    """
    Save feature array and file_item mapping to disk
    :param features_filename: path to save features to
    :param features: array of features
    :param mapping_filename: path to save mapping to
    :param file_mapping: mapping from array_index to file_path/plaintext_word
    """
    print ("Saving features...")
    np.save('%s.npy' % features_filename, features)
    with open('%s.json' % mapping_filename, 'w') as index_file:
        json.dump(file_mapping, index_file)
    logger.info("Weights saved")


def load_features(features_filename, mapping_filename):
    """
    Loads features and file_item mapping from disk
    :param features_filename: path to load features from
    :param mapping_filename: path to load mapping from
    :return: feature array and file_item mapping to disk

    """
    print ("Loading features...")
    images_features = np.load('%s.npy' % features_filename)
    with open('%s.json' % mapping_filename) as f:
        index_str = json.load(f)
        file_index = {int(k): str(v) for k, v in index_str.items()}
    return images_features, file_index


def index_features(features, n_trees=1000, dims=4096, is_dict=False):
    """
    Use Annoy to index our features to be able to query them rapidly
    :param features: array of item features
    :param n_trees: number of trees to use for Annoy. Higher is more precise but slower.
    :param dims: dimension of our features
    :return: an Annoy tree of indexed features
    """
    print ("Indexing features...")
    feature_index = AnnoyIndex(dims, metric='angular')
    for i, row in enumerate(features):
        vec = row
        if is_dict:
            vec = features[row]
        feature_index.add_item(i, vec)
    feature_index.build(n_trees)
    return feature_index


def build_word_index(word_vectors):
    """
    Builds a fast index out of a list of pretrained word vectors
    :param word_vectors: a list of pre-trained word vectors loaded from a file
    :return: an Annoy tree of indexed word vectors and a mapping from the Annoy index to the word string
    """
    print ("Building word index ...")
    logging.info("Creating mapping and list of features")
    word_list = [(i, word) for i, word in enumerate(word_vectors)]
    word_mapping = {k: v for k, v in word_list}
    word_features = [word_vectors[lis[1]] for lis in word_list]
    logging.info("Building tree")
    word_index = index_features(word_features, n_trees=20, dims=300)
    logging.info("Tree built")
    return word_index, word_mapping


def search_index_by_key(key, feature_index, item_mapping, top_n=10):
    """
    Search an Annoy index by key, return n nearest items
    :param key: the index of our item in our array of features
    :param feature_index: an Annoy tree of indexed features
    :param item_mapping: mapping from indices to paths/names
    :param top_n: how many items to return
    :return: an array of [index, item, distance] of size top_n
    """
    distances = feature_index.get_nns_by_item(key, top_n, include_distances=True)
    return [[a, item_mapping[a], distances[1][i]] for i, a in enumerate(distances[0])]


def search_index_by_value(vector, feature_index, item_mapping, top_n=10):
    """
    Search an Annoy index by value, return n nearest items
    :param vector: the index of our item in our array of features
    :param feature_index: an Annoy tree of indexed features
    :param item_mapping: mapping from indices to paths/names
    :param top_n: how many items to return
    :return: an array of [index, item, distance] of size top_n
    """
    distances = feature_index.get_nns_by_vector(vector, top_n, include_distances=True)
    return [[a, item_mapping[a], distances[1][i]] for i, a in enumerate(distances[0])]


def get_weighted_features(class_index, images_features):
    """
    Use class weights to re-weigh our features
    :param class_index: Which Imagenet class index to weigh our features on
    :param images_features: Unweighted features
    :return: Array of weighted activations
    """
    class_weights = get_class_weights_from_vgg()
    target_class_weights = class_weights[:, class_index]
    weighted = images_features * target_class_weights
    return weighted


def get_class_weights_from_vgg(save_weights=False, filename='class_weights'):
    """
    Get the class weights for the final predictions layer as a numpy martrix, and potentially save it to disk.
    :param save_weights: flag to save to disk
    :param filename: filename if we save to disc
    :return: n_classes*4096 array of weights from the penultimate layer to the last layer in Keras' pretrained VGG
    """
    model_weights_path = os.path.join(os.environ.get('HOME'),
                                      '.keras/models/vgg16_weights_tf_dim_ordering_tf_kernels.h5')
    weights_file = h5py.File(model_weights_path, 'r')
    weights_file.get('predictions').get('predictions_W_1:0')
    final_weights = weights_file.get('predictions').get('predictions_W_1:0')

    class_weights = np.array(final_weights)[:]
    weights_file.close()
    if save_weights:
        np.save('%s.npy' % filename, class_weights)
    return class_weights


def setup_custom_model(intermediate_dim=2000, word_embedding_dim=300):
    """
    Builds a custom model taking the fc2 layer of VGG16 and adding two dense layers on top
    :param intermediate_dim: dimension of the intermediate dense layer
    :param word_embedding_dim: dimension of the final layer, which should match the size of our word embeddings
    :return: a Keras model with the backbone frozen, and the upper layers ready to be trained
    """
    print ("Setting up custom model ...")
    headless_pretrained_vgg16 = VGG16(weights='imagenet', include_top=True, input_shape=(224, 224, 3))
    x = headless_pretrained_vgg16.get_layer('fc2').output

    # We do not re-train VGG entirely here, just to get to a result quicker (fine-tuning the whole network would
    # lead to better results)
    for layer in headless_pretrained_vgg16.layers:
        layer.trainable = False

    image_dense1 = Dense(intermediate_dim, name="image_dense1")(x)
    image_dense1 = BatchNormalization()(image_dense1)
    image_dense1 = Activation("relu")(image_dense1)
    image_dense1 = Dropout(0.5)(image_dense1)

    image_dense2 = Dense(word_embedding_dim, name="image_dense2")(image_dense1)
    image_output = BatchNormalization()(image_dense2)

    complete_model = Model(inputs=[headless_pretrained_vgg16.input], outputs=image_output)
    sgd = optimizers.SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
    complete_model.compile(optimizer=sgd, loss=cosine_proximity)
    return complete_model


def load_glove_vectors(glove_dir, glove_name='glove.6B.300d.txt'):
    """
    Mostly from keras docs here https://blog.keras.io/using-pre-trained-word-embeddings-in-a-keras-model.html
    Download GloVe vectors here http://nlp.stanford.edu/data/glove.6B.zip
    :param glove_name: name of pre-trained file
    :param glove_dir: directory in witch the glove file is located
    :return:
    """
    f = open(os.path.join(glove_dir, glove_name))
    embeddings_index = {}
    for line in f:
        values = line.split()
        word = values[0]
        coefs = np.asarray(values[1:], dtype='float32')
        embeddings_index[word] = coefs
    f.close()
    print('Found %s word vectors.' % len(embeddings_index))
    return embeddings_index


# Training the model

if __name__ == "__main__":
    parser = build_parser()
    options = parser.parse_args()
    model_save_path = options.model_save_path
    checkpoint_path = options.checkpoint_path
    glove_path = options.glove_path
    dataset_path = options.dataset_path
    num_epochs = options.num_epochs

    word_vectors = vector_search.load_glove_vectors(glove_path)
    images, vectors, image_paths = load_paired_img_wrd(dataset_path, word_vectors)
    x, y = shuffle(images, vectors, random_state=2)
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=2)

    checkpointer = ModelCheckpoint(filepath=checkpoint_path, verbose=1, save_best_only=True)
    custom_model = vector_search.setup_custom_model()
    custom_model.fit(X_train, y_train, validation_data=(X_test, y_test),
                     epochs=num_epochs, batch_size=32, callbacks=[checkpointer])
    custom_model.save(model_save_path)
    

#Searching the model

def index_images(folder, features_path, mapping_path, model, features_from_new_model_boolean, glove_path):
    print ("Now indexing images...")
    # Use word vectors if leveraging the new model
    if features_from_new_model_boolean:
        word_vectors=vector_search.load_glove_vectors(glove_path)
    else:
        word_vectors=[]
    # Use utiliy function
    _, _, paths = load_paired_img_wrd(
        folder=folder, 
        word_vectors=word_vectors,
        use_word_vectors=features_from_new_model_boolean)
    images_features, file_index = vector_search.generate_features(paths, model)
    vector_search.save_features(features_path, images_features, mapping_path, file_index)
    return images_features, file_index


# This is an inefficient implimentation for the proof of context
def get_index(input_image, file_mapping):
    for index, file in file_mapping.items():
        if file == input_image:
            return index
    raise ValueError("Image %s not indexed" % input_image)

def generate_features(index_folder, features_path, file_mapping, loaded_model, features_from_new_model_boolean, glove_path):
    features, index = index_images(
        index_folder, 
        features_path, 
        file_mapping, 
        loaded_model, 
        features_from_new_model_boolean,
        glove_path)
    print("Indexed %s images" % len(features))


def build_index_and_search_through_it(images_features, file_index):
    # Decide whether to do only image search or hybrid search
    if not features_from_new_model_boolean:
        # This is pure image search
        image_index = vector_search.index_features(images_features, dims=4096)
        search_key = get_index(input_image, file_index)
        results = vector_search.search_index_by_key(search_key, image_index, file_index)
        print(results)
    else:
        word_vectors = vector_search.load_glove_vectors(glove_path)
        # If we are searching for tags for an image
        if not input_word:
            # Work on a single image instead of indexing
            search_key = get_index(input_image, file_index)
            word_index, word_mapping = vector_search.build_word_index(word_vectors)
            results = vector_search.search_index_by_value(images_features[search_key], word_index, word_mapping)
        # If we are using words to search through our images
        else:
            image_index = vector_search.index_features(images_features, dims=300)
            results = vector_search.search_index_by_value(word_vectors[input_word], image_index, file_index)
        print(results)

if __name__ == "__main__":
    parser = build_parser()
    options = parser.parse_args()
    features_path = options.features_path
    file_mapping = options.file_mapping
    index_folder = options.index_folder
    input_image = options.input_image
    input_word = options.input_word
    model_path = options.model_path
    glove_path = options.glove_path
    index_boolean = str2bool(options.index_boolean)
    features_from_new_model_boolean = str2bool(options.features_from_new_model_boolean)

    check_inputs(
        index_folder, 
        input_image, 
        input_word, 
        model_path, 
        glove_path)

    # Decide whether to use pre-trained VGG or custom model, if one was provided
    if model_path:
        loaded_model = load_model(model_path)
    else:
        loaded_model = vector_search.load_headless_pretrained_model()

    # Decide whether to index the images (if you already have them) or load images to disk
    if index_boolean:
        generate_features(index_folder, features_path, file_mapping, loaded_model, features_from_new_model_boolean, glove_path)
    else:
        images_features, file_index = vector_search.load_features(features_path, file_mapping)
        build_index_and_search_through_it(images_features, file_index)

    
show_top_n(9, results, search_by_img=False)
st.header("Finish")

